//
//  Node.cpp
//  racetrack_two
//
//  Created by Spencer McClure on 10/28/12.
//
//

#include "HeapableNode.h"

