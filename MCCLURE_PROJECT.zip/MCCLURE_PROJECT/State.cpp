//
//  State.cpp
//  racetrack_two
//
//  Created by Spencer McClure on 10/29/12.
//
//

#include "State.h"


//standard setter
//for some reason couldn't work in the .h
void State::setPrevSpeed(Point* prev_spd)
{
    prev_speed = prev_spd;
}