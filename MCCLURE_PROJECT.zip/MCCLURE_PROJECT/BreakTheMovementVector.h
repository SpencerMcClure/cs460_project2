//
//  BreakTheMovementVector.h
//  racetrack_two
//
//  Created by Spencer McClure on 10/24/12.
//
//

#ifndef BREAK_THE_MOVEMENT_VECTOR
#define BREAK_THE_MOVEMENT_VECTOR
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

vector<int*> breakTheMovementVector(int i, int j);

#endif
