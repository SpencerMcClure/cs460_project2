README

Instructions to run
Run the following two commands on aludra within project directory. 
make, then run a.out
No visualization - any extra (or too few) inputs on the command-line will cause program to fail

Example:

make
./a.out -i racetrack1.txt -o output.txt -h1|h2 -t1|t2



