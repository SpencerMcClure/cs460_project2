//
//  Point.cpp
//  racetrack_two
//
//  Created by Spencer McClure on 10/29/12.
//
//

#include "Point.h"
